<?php
/*
Plugin Name: Custom Font Changer
Description: Changes the website font to Times New Roman and color to green upon activation, and red upon deactivation.
Version: 1.0
Author: Your Name
*/

// Function to add custom styles on activation
function activate_custom_font_changer() {
    $custom_css = "
        body {
            font-family: 'Times New Roman', Times, serif !important;
            color: green !important;
        }
    ";

    // Inject custom CSS into the site head on activation
    update_option('custom_font_changer_css', $custom_css);
}

// Function to apply the styles
function apply_custom_font_changer_styles() {
    $custom_css = get_option('custom_font_changer_css');
    if ($custom_css) {
        echo '<style>' . $custom_css . '</style>';
    }
}

// Hook the function to 'wp_head' to inject CSS into the frontend
add_action('wp_head', 'apply_custom_font_changer_styles');

// On activation, change the font and color to Times New Roman and green
register_activation_hook(__FILE__, 'activate_custom_font_changer');

// Function to change font color to red on deactivation
function deactivate_custom_font_changer() {
    $custom_css = "
        body {
            font-family: 'Times New Roman', Times, serif !important;
            color: red !important;
        }
    ";

    // Update the CSS to change the font color to red
    update_option('custom_font_changer_css', $custom_css);
}

// On deactivation, change the font color to red
register_deactivation_hook(__FILE__, 'deactivate_custom_font_changer');

// Cleanup on uninstall (optional)
function uninstall_custom_font_changer() {
    // Remove the custom CSS option when the plugin is uninstalled
    delete_option('custom_font_changer_css');
}

// Register uninstall hook
register_uninstall_hook(__FILE__, 'uninstall_custom_font_changer');
